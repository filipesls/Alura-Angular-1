angular.module('alurapic').controller('FotosController', function($scope) {
	
	$scope.foto = {
		titulo : 'Leão',
		url : 'http://www.fundosanimais.com/Minis/leoes.jpg'
	}; 

});